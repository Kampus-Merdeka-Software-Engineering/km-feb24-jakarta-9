// Variabel global untuk menyimpan data
let cachedData = null;
// Variabel untuk menyimpan data yang akan dipakai untuk visualisasi dan filter
let filteredData = null;

// Fungsi untuk mengambil data
async function fetchDataIfNeeded() {
  if (cachedData === null) {
    try {
      const response = await fetch(
        "https://raw.githubusercontent.com/Jakarta-9/Dataset-NYC-Property-Sales/main/NYC-dataset-Team-9.json"
      );
      cachedData = await response.json();
      // Set filteredData sama dengan cachedData saat pertama kali diambil
      filteredData = cachedData;
    } catch (error) {
      console.error("Failed to fetch data:", error);
    }
  }
  return cachedData;
}

// Fungsi untuk memfilter data berdasarkan checkbox borough, date, dan year
// Fungsi untuk memfilter data berdasarkan checkbox borough, date, dan year
async function filterData() {
  // Ambil nilai yang dipilih dari checkbox borough
  const selectedBoroughs = Array.from(
    document.querySelectorAll('input[name="borough"]:checked')
  ).map((cb) => cb.value);
  // Ambil nilai yang dipilih dari checkbox date
  const selectedDates = Array.from(
    document.querySelectorAll('input[name="date"]:checked')
  ).map((cb) => cb.value);
  // Ambil nilai yang dipilih dari checkbox year
  const selectedYears = Array.from(
    document.querySelectorAll('input[name="year"]:checked')
  ).map((cb) => cb.value);

  // Filter data berdasarkan checkbox yang dicentang
  filteredData = cachedData.filter((item) => {
    const saleDate = new Date(item.SALE_DATE);
    const saleMonthYear = saleDate.toLocaleString("default", {
      month: "short",
      year: "numeric",
    });
    const saleYear = saleDate.getFullYear().toString();

    return (
      (selectedBoroughs.length === 0 ||
        selectedBoroughs.includes(item.BOROUGH_NAME)) &&
      (selectedDates.length === 0 || selectedDates.includes(saleMonthYear)) &&
      (selectedYears.length === 0 || selectedYears.includes(saleYear))
    );
  });

  // Panggil fungsi visualize untuk memperbarui visualisasi
  await visualize(filteredData); // Perbaiki pemanggilan dengan mengirimkan filteredData
}

async function visualize(data) { // Perbaiki fungsi untuk menerima argumen data
  filteredChart(data); // Perbaiki pemanggilan dengan mengirimkan data
}

// Fungsi untuk memperbarui visualisasi berdasarkan data yang difilter
async function filteredChart(data) {
  // Memanggil updateTotals() untuk memperbarui total setelah pemfilteran data
  await updateTotals(data); // Perbaiki pemanggilan dengan mengirimkan data
  // Panggil fungsi untuk memperbarui line chart dan bar chart
  await fetchLineChartData(data);
  await renderBarChart(data);

  // Persiapkan dan render bar chart kedua
  const { barLabels, barDatasets } = prepareChartData(data);
  renderBarChart2(barLabels, barDatasets);
}

// Fungsi untuk mengisi dropdown borough
// Fungsi untuk mengisi dropdown borough
async function populateBoroughDropdown() {
  const data = await fetchDataIfNeeded();
  const boroughOrder = [
    "Manhattan",
    "Brooklyn",
    "Queens",
    "Bronx",
    "Staten Island",
  ];
  const uniqueBoroughs = Array.from(
    new Set(data.map((item) => item.BOROUGH_NAME))
  ).sort((a, b) => boroughOrder.indexOf(a) - boroughOrder.indexOf(b));

  const dropdownBorough = document.getElementById("dropdown-borough");
  dropdownBorough.innerHTML = ""; // Kosongkan konten sebelumnya

  uniqueBoroughs.forEach((borough) => {
    const label = document.createElement("label");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.name = "borough"; // Tambahkan name untuk checkbox
    checkbox.value = borough; // Tambahkan value untuk checkbox
    checkbox.id = `borough-${borough}`; // Tambahkan ID unik untuk checkbox
    checkbox.checked = true; // Setel checkbox aktif secara default
    label.htmlFor = `borough-${borough}`; // Hubungkan label dengan checkbox berdasarkan ID
    label.appendChild(checkbox);
    label.appendChild(document.createTextNode(borough));
    dropdownBorough.appendChild(label);
  });

  // Tambahkan event listener untuk mencegah menutup dropdown saat mengklik di dalamnya
  dropdownBorough.addEventListener("click", function (event) {
    event.stopPropagation();
  });
}

// Fungsi untuk mengisi dropdown bulan, tahun pada date
async function populateDateDropdown() {
  const startDate = new Date("2016-09-01");
  const endDate = new Date("2017-08-31");

  const dropdownDate = document.getElementById("dropdown-date");
  dropdownDate.innerHTML = ""; // Kosongkan konten sebelumnya

  const months = [];
  let currentDate = new Date(startDate);
  while (currentDate <= endDate) {
    const month = currentDate.toLocaleString("default", { month: "short" });
    const year = currentDate.getFullYear();
    months.push(`${month} ${year}`);
    currentDate.setMonth(currentDate.getMonth() + 1);
  }

  months.forEach((monthYear) => {
    const label = document.createElement("label");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.name = "date"; // Tambahkan name untuk checkbox
    checkbox.value = monthYear; // Tambahkan value untuk checkbox
    checkbox.id = `date-${monthYear}`;
    checkbox.checked = true; // Setel checkbox aktif secara default
    label.htmlFor = `date-${monthYear}`;
    label.appendChild(checkbox);
    label.appendChild(document.createTextNode(monthYear));
    dropdownDate.appendChild(label);
  });

  // Tambahkan event listener untuk mencegah menutup dropdown saat mengklik di dalamnya
  dropdownDate.addEventListener("click", function (event) {
    event.stopPropagation();
  });
}

// Fungsi untuk mengisi dropdown tahun
async function populateYearDropdown() {
  const data = await fetchDataIfNeeded();
  const years = new Set();

  data.forEach((item) => {
    const date = new Date(item.SALE_DATE);
    const year = date.getFullYear();
    if (!isNaN(year)) {
      // Periksa apakah tahun adalah valid number
      years.add(year);
    }
  });

  const dropdownYear = document.getElementById("dropdown-year");
  dropdownYear.innerHTML = ""; // Kosongkan konten sebelumnya

  years.forEach((year) => {
    const label = document.createElement("label");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.name = "year"; // Tambahkan name untuk checkbox
    checkbox.value = year; // Tambahkan value untuk checkbox
    checkbox.id = `year-${year}`; // Tambahkan ID unik untuk checkbox
    checkbox.checked = true; // Setel checkbox aktif secara default
    label.htmlFor = `year-${year}`; // Hubungkan label dengan checkbox berdasarkan ID
    label.appendChild(checkbox);
    label.appendChild(document.createTextNode(year));
    dropdownYear.appendChild(label);
  });

  // Tambahkan event listener untuk mencegah menutup dropdown saat mengklik di dalamnya
  dropdownYear.addEventListener("click", function (event) {
    event.stopPropagation();
  });
}

// Event listener untuk memuat data saat halaman dimuat
// Event listener untuk memuat data saat halaman dimuat
window.onload = async function () {
  await fetchDataIfNeeded(); // Ambil data pertama kali
  await populateBoroughDropdown(); // Isi dropdown borough
  await populateDateDropdown(); // Isi dropdown bulan, tahun pada date
  await populateYearDropdown(); // Isi dropdown tahun
  await filterData(); // Panggil filterData di sini agar filteredData diinisialisasi

  // Tambahkan event listener ke tombol filter
  const filterButton = document.getElementById("filter-button");
  filterButton.addEventListener("click", async function(event) {
    await filterData(); // Panggil filterData saat tombol filter diklik
  });
};
async function filterAndRenderCharts() {
  try {
    // Ambil nilai filter dari input checkbox
    const boroughFilters = Array.from(document.querySelectorAll('input[name="borough"]:checked')).map((checkbox) => checkbox.value);
    const dateFilters = Array.from(document.querySelectorAll('input[name="date"]:checked')).map((checkbox) => checkbox.value);
    const yearFilters = Array.from(document.querySelectorAll('input[name="year"]:checked')).map((checkbox) => checkbox.value);

    // Ambil data dengan filter yang diberikan
    const filteredData = await fetchNYCPropertyData({
      borough: boroughFilters,
      date: dateFilters,
      year: yearFilters,
    });

    if (filteredData) {
      // Persiapkan data untuk grafik
      const { barLabels, barDatasets } = prepareChartData(filteredData);
      // Render grafik
      renderBarChart2(barLabels, barDatasets);
    }
  } catch (error) {
    console.error("Error fetching or parsing data:", error);
  }
}



// Fungsi untuk memperbarui total
// Fungsi untuk memperbarui total
// Fungsi untuk memperbarui total
async function updateTotals() {
  // Ambil data dari filteredData, jika tidak ada filter aktif, gunakan data mentah
  let data = filteredData.length === 0 ? cachedData : filteredData;

  // Periksa apakah semua filter tercentang saat halaman dimuat
  const allBoroughsChecked =
    Array.from(document.querySelectorAll('input[name="borough"]:checked'))
      .length === document.querySelectorAll('input[name="borough"]').length;
  const allDatesChecked =
    Array.from(document.querySelectorAll('input[name="date"]:checked'))
      .length === document.querySelectorAll('input[name="date"]').length;
  const allYearsChecked =
    Array.from(document.querySelectorAll('input[name="year"]:checked'))
      .length === document.querySelectorAll('input[name="year"]').length;

  // Periksa apakah semua filter borough tercentang saat halaman dimuat
  const allBoroughsUnchecked =
    Array.from(document.querySelectorAll('input[name="borough"]:checked'))
      .length === 0;

  // Periksa apakah semua filter date tercentang saat halaman dimuat
  const allDatesUnchecked =
    Array.from(document.querySelectorAll('input[name="date"]:checked'))
      .length === 0;

  // Periksa apakah semua filter year tercentang saat halaman dimuat
  const allYearsUnchecked =
    Array.from(document.querySelectorAll('input[name="year"]:checked'))
      .length === 0;

  // Jika salah satu filter tidak dicentang semua, gunakan data kosong
  if (allBoroughsUnchecked || allDatesUnchecked || allYearsUnchecked) {
    data = [];
  }

  // Jika semua filter tercentang, gunakan data mentah
  if (allBoroughsChecked && allDatesChecked && allYearsChecked) {
    data = cachedData;
  }

  // Total keseluruhan untuk kolom TOTAL_UNITS
  const totalUnits = data.reduce(
    (acc, property) => acc + parseFloat(property.TOTAL_UNITS),
    0
  );

  // Buat Set untuk menyimpan nilai unik dari kolom BOROUGH_NAME
  const uniqueBoroughs = new Set(data.map((property) => property.BOROUGH_NAME));

  // Hitung total untuk setiap kolom hanya untuk nilai unik di kolom BOROUGH_NAME
  const totalBorough = uniqueBoroughs.size;
  const totalSalePrice =
    data.reduce((acc, property) => acc + parseFloat(property.SALE_PRICE), 0) /
    1000000000; // Ubah ke milyar
  const totalLot =
    data.reduce((acc, property) => acc + parseFloat(property.LOT), 0) / 1000000; // Ubah ke juta

  // Format total sale price menjadi format yang diinginkan (misal: 89,3M)
  const formattedTotalSalePrice =
    (Math.round(totalSalePrice * 10) / 10)
      .toLocaleString("id-ID", {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1,
      })
      .replace(".", ",") + "M";

  // Format total lot menjadi format yang diinginkan (misal: 31,8 jt)
  const formattedTotalLot =
    (Math.round(totalLot * 10) / 10)
      .toLocaleString("id-ID", {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1,
      })
      .replace(".", ",") + " jt";

  // Perbarui nilai elemen HTML
// Perbarui nilai elemen HTML
// Perbarui nilai elemen HTML
// Perbarui nilai elemen HTML
document.querySelector(".col-total-borough h1").textContent = allBoroughsUnchecked ? "0" : totalBorough;
document.querySelector(".col-total-sale-price h1").textContent = (allBoroughsUnchecked || allDatesUnchecked || allYearsUnchecked) ? "0,0 M" : formattedTotalSalePrice;
document.querySelector(".col-total-lot h1").textContent = (allBoroughsUnchecked || allDatesUnchecked || allYearsUnchecked) ? "0,0 jt" : formattedTotalLot;
document.querySelector(".col-total-units h1").textContent = allBoroughsUnchecked ? "0" : totalUnits;
}

//line chart
// Fungsi untuk mengambil data dan memperbarui chart berdasarkan filter

//line chart
// Fungsi untuk mengambil data dan memperbarui chart berdasarkan filter
// Fungsi untuk mengambil data dan memperbarui chart berdasarkan filter
async function fetchLineChartData(filteredData = null) {
  try {
    // Jika filteredData tidak null, gunakan data yang sudah difilter
    let data = filteredData || (await fetchDataIfNeeded());

    console.log("Filtered Data:", data); // Log data yang difilter

    // Daftar warna yang ditentukan
    const boroughColors = {
      Manhattan: 'gray',
      Bronx: 'navy',
      Queens: 'powder blue',
      "Staten Island": 'teal',
      Brooklyn: 'purple'
    };

    // Ekstrak bulan, tahun, dan harga penjualan dari data
    const salesData = {};
    const startDate = new Date("2016-09-01");
    const endDate = new Date("2017-08-31");

    data.forEach((entry) => {
      const saleDate = new Date(entry["SALE_DATE"]);
      const salePrice = parseFloat(entry["SALE_PRICE"]);
      const borough = entry["BOROUGH_NAME"];

      // Cek apakah filter borough, date, dan year terpilih
      const boroughChecked = Array.from(document.querySelectorAll('input[name="borough"]:checked')).length > 0;
      const datesChecked = Array.from(document.querySelectorAll('input[name="date"]:checked')).length > 0;
      const yearsChecked = Array.from(document.querySelectorAll('input[name="year"]:checked')).length > 0;

      if (!isNaN(salePrice) && saleDate >= startDate && saleDate <= endDate && boroughChecked && datesChecked && yearsChecked) {
        const month = saleDate.toLocaleString("default", { month: "short" });
        const year = saleDate.getFullYear();
        const label = `${month} ${year}`;

        if (!salesData[borough]) {
          salesData[borough] = {};
        }

        if (!salesData[borough][label]) {
          salesData[borough][label] = 0;
        }

        salesData[borough][label] += salePrice; // Menambahkan harga penjualan ke label yang sesuai
      }
    });

    // Menyiapkan data untuk chart
    const labelsSet = new Set();
    const datasets = [];

    Object.keys(salesData).forEach((borough) => {
      Object.keys(salesData[borough]).forEach((label) => {
        labelsSet.add(label);
      });
    });

    const labels = Array.from(labelsSet).sort((a, b) => {
      const [monthA, yearA] = a.split(" ");
      const [monthB, yearB] = b.split(" ");
      return (
        new Date(`${monthA} 1, ${yearA}`) - new Date(`${monthB} 1, ${yearB}`)
      );
    });

    console.log("Labels:", labels); // Log labels

    Object.keys(salesData).forEach((borough) => {
      const data = labels.map((label) => salesData[borough][label] || 0);

      datasets.push({
        label: borough,
        data: data,
        fill: false,
        borderColor: boroughColors[borough],
        tension: 0.1,
        hidden: !document.querySelector(`input[name="borough"][value="${borough}"]:checked`) // Sembunyikan dataset jika filter borough tidak dipilih
      });
    });

    console.log("Datasets:", datasets); // Log datasets

    const dataForChart = {
      labels: labels,
      datasets: datasets,
    };

    const config = {
      type: "line",
      data: dataForChart,
      options: {
        scales: {
          x: {
            title: {
              display: true,
              text: "Month, Year",
            },
          },
          y: {
            title: {
              display: true,
              text: "Sale Price",
            },
          },
        },
      },
    };

    // Hapus chart lama jika ada
    const chartContainer = document.getElementById("myChart");
    if (chartContainer.chart) {
      chartContainer.chart.destroy();
    }

    // Buat chart baru
    chartContainer.chart = new Chart(chartContainer, config);
  } catch (error) {
    console.error("Error fetching or parsing data:", error);
  }
}
// Fungsi untuk mengumpulkan dan memproses data untuk grafik batang
async function fetchBarChartData(filteredData = null) {
  try {
    // Ambil data yang sudah difilter atau data mentah jika tidak ada filter
    const data = filteredData || (await fetchDataIfNeeded());
    // Daftar warna yang ditentukan
    const boroughColors = {
      Manhattan: 'gray',
      Bronx: 'navy',
      Queens: 'powder blue',
      "Staten Island": 'teal',
      Brooklyn: 'purple'
    };

    // Mengelompokkan data berdasarkan tahun dari SALE_DATE dan BOROUGH_NAME
    const groupedData = {};
    data.forEach((entry) => {
      const year = new Date(entry["SALE_DATE"]).getFullYear();
      const borough = entry["BOROUGH_NAME"] || entry["BOROUGH"];

      // Cek apakah filter borough, date, dan year terpilih
      const boroughChecked = Array.from(document.querySelectorAll('input[name="borough"]:checked')).length > 0;
      const datesChecked = Array.from(document.querySelectorAll('input[name="date"]:checked')).length > 0;
      const yearsChecked = Array.from(document.querySelectorAll('input[name="year"]:checked')).length > 0;

      // Hanya tambahkan data jika filter borough, date, dan year terpilih
      if (boroughChecked && datesChecked && yearsChecked) {
        if (!groupedData[year]) {
          groupedData[year] = {};
        }

        if (!groupedData[year][borough]) {
          groupedData[year][borough] = {
            totalUnits: 0,
          };
        }

        // Menambahkan total dari kedua kolom RESIDENTIAL_UNITS dan COMMERCIAL_UNITS
        const residentialUnits = parseFloat(entry["RESIDENTIAL_UNITS"]) || 0;
        const commercialUnits = parseFloat(entry["COMMERCIAL_UNITS"]) || 0;

        // Hanya menambahkan jika nilai tidak NaN
        if (!isNaN(residentialUnits) && !isNaN(commercialUnits)) {
          groupedData[year][borough].totalUnits +=
            residentialUnits + commercialUnits;
        }
      }
    });

    // Mengumpulkan tahun-tahun yang valid (tanpa NaN)
    const years = Object.keys(groupedData).filter(
      (year) => !isNaN(parseInt(year))
    );

    // Mengumpulkan boroughs yang unik
    const boroughs = new Set();
    years.forEach((year) => {
      Object.keys(groupedData[year]).forEach((borough) => {
        boroughs.add(borough);
      });
    });

    // Mengatur data untuk dataset chart
    const datasets = Array.from(boroughs).map((borough) => {
      const data = years.map(
        (year) => groupedData[year][borough]?.totalUnits || 0
      ); // Menggunakan optional chaining untuk menghindari kesalahan jika data tidak ada
      return {
        label: borough,
        data: data,
        backgroundColor: boroughColors[borough], // Menggunakan warna sesuai borough
        borderColor: boroughColors[borough],
        borderWidth: 1,
      };
    });

    return {
      labels: years,
      datasets: datasets,
    };
  } catch (error) {
    console.error("Error fetching or parsing data:", error);
  }
}

// Fungsi untuk merender grafik batang
async function renderBarChart(filteredData = null) {
  try {
    const barData = await fetchBarChartData(filteredData);

    const config = {
      type: "bar",
      data: barData,
      options: {
        indexAxis: "y", // Mengatur orientasi grafik menjadi horizontal
        scales: {
          x: {
            title: {
              display: true,
              text: "Total Units",
            },
            beginAtZero: true,
            ticks: {
              callback: function (value) {
                return value.toLocaleString();
              },
            },
          },
          y: {
            title: {
              display: true,
              text: "Year",
            },
          },
        },
      },
    };

    // Hapus chart lama jika ada
    const chartContainer = document.getElementById("barChart");
    if (chartContainer.chart) {
      chartContainer.chart.destroy();
    }

    // Buat chart baru
    chartContainer.chart = new Chart(chartContainer, config);
  } catch (error) {
    console.error("Error fetching or parsing data:", error);
  }
}

//bar chart 2
// Fungsi untuk mengambil data properti NYC dengan filter
async function fetchNYCPropertyData(filteredData = null) {
  try {
    // Ambil data dari cache jika tersedia atau dari sumber data jika tidak
    let data = filteredData || (await fetchDataIfNeeded());

    console.log("Data fetched:", data);
    return data;
  } catch (error) {
    // Tampilkan pesan kesalahan jika gagal mengambil data
    const errorMessage = "Gagal mengambil data properti NYC. Silakan coba lagi nanti.";
    alert(errorMessage);
    console.error(errorMessage, error);
    return null;
  }
}

function prepareChartData(data) {
  const barLabels = [];
  const residentialUnits = Array(12).fill(0);
  const commercialUnits = Array(12).fill(0);

  // Inisialisasi tanggal minimum dan maksimum dengan tanggal awal dan akhir yang mungkin
  let minDate = new Date("2016-09-01");
  let maxDate = new Date("2017-08-31");

  // Jika data tersedia, tentukan tanggal minimum dan maksimum berdasarkan data yang diberikan
  if (data && data.length > 0) {
    // Filter data berdasarkan rentang tanggal yang ditentukan
    data = data.filter(entry => {
      const saleDate = new Date(entry.SALE_DATE);
      return saleDate >= minDate && saleDate <= maxDate;
    });

    // Tentukan ulang tanggal minimum dan maksimum berdasarkan data yang sudah difilter
    const saleDates = data.map(entry => new Date(entry.SALE_DATE));
    minDate = new Date(Math.min(...saleDates));
    maxDate = new Date(Math.max(...saleDates));
  }

  // Buat label bulan dan tahun berdasarkan rentang tanggal yang ditentukan
  let currentDate = new Date(minDate);
  while (currentDate <= maxDate) {
    const monthYear = currentDate.toLocaleString("en-us", {
      month: "long",
      year: "numeric",
    });
    barLabels.push(monthYear);
    currentDate.setMonth(currentDate.getMonth() + 1);
  }

  // Hitung total unit per bulan
  data.forEach((entry) => {
    const saleDate = new Date(entry.SALE_DATE);
    const monthIndex = saleDate.getMonth();
    residentialUnits[monthIndex] += entry.RESIDENTIAL_UNITS;
    commercialUnits[monthIndex] += entry.COMMERCIAL_UNITS;
  });

  const barDatasets = [
    {
      label: "Total COMMERCIAL_UNITS",
      data: commercialUnits,
      backgroundColor: "rgba(54, 162, 235, 0.2)",
      borderColor: "rgb(54, 162, 235)",
      borderWidth: 1,
    },
    {
      label: "Total RESIDENTIAL_UNITS",
      data: residentialUnits,
      backgroundColor: "rgba(255, 99, 132, 0.2)",
      borderColor: "rgb(255, 99, 132)",
      borderWidth: 1,
    },
  ];

  return { barLabels, barDatasets };
}


function renderBarChart2(barLabels, barDatasets) {
  const barCtx = document.getElementById("barChart2").getContext("2d");
  if (barCtx.chart) {
    barCtx.chart.destroy(); // Hancurkan grafik sebelumnya jika ada
  }
  barCtx.chart = new Chart(barCtx, {
    type: "bar",
    data: {
      labels: barLabels,
      datasets: barDatasets,
    },
    options: {
      scales: {
        x: {
          title: {
            display: true,
            text: "Month, Year",
          },
        },
        y: {
          title: {
            display: true,
            text: "Total Units",
          },
          beginAtZero: true,
        },
      },
    },
  });
}

async function filterAndRenderCharts() {
  try {
    // Ambil nilai filter dari input checkbox
    const boroughFilters = Array.from(document.querySelectorAll('input[name="borough"]:checked')).map((checkbox) => checkbox.value);
    const dateFilters = Array.from(document.querySelectorAll('input[name="date"]:checked')).map((checkbox) => checkbox.value);
    const yearFilters = Array.from(document.querySelectorAll('input[name="year"]:checked')).map((checkbox) => checkbox.value);

    // Ambil data dengan filter yang diberikan
    const filteredData = await fetchNYCPropertyData({
      borough: boroughFilters,
      date: dateFilters,
      year: yearFilters,
    });

    if (filteredData) {
      // Persiapkan data untuk grafik
      const { barLabels, barDatasets } = prepareChartData(filteredData);
      // Render grafik
      renderBarChart2(barLabels, barDatasets);
    }
  } catch (error) {
    console.error("Error fetching or parsing data:", error);
  }
}

document.addEventListener("DOMContentLoaded", filterAndRenderCharts);
